from random import *
from nationality import *
drivers=[]
min_ability=0
max_ability=100
ability_values=[]
counter=1

for i in range(max_ability,min_ability+1,-1):
    for j in range(counter):
        ability_values.append(i)
    counter += 1
    
id=0
def generate_ability():
    return ability_values[randrange(len(ability_values))]

def generate_driver():
    name=generate_name()
    ability=generate_ability()
    drivers.append(Person(name[0],name[1],name[2],ability))
    print("new driver",name[0],name[1],name[2],ability)

def update_driver_abilities():
    for i in range(len(drivers)):
        drivers[i].ability=drivers[i].ability+randrange(5)
    print('abilities updated')

def Ability():
    return ability_values [ randrange( len( ability_values ) ) ]
def print_person():
    for i in range(len(drivers)):
        print(drivers[i].first_name,drivers[i].last_name,drivers[i].nationality,drivers[i].ability)
class Person:
    def __init__( self , first_name , last_name , nationality , ability ) :
        self.first_name = first_name
        self.last_name = last_name
        self.nationality = nationality
        self.age = 15
        self.ability = ability
        #global id
        #self.id = id
        #id += 1

#class Person_name:
 #   def __init__( self , name , frequency ) :
  #      self.name = name
   #     self.frequency = frequency

#class Nationality:
 #   def __init__( self , name , abberivation ,frequency ) :
  #      self.name = name
   #     self.abberivation = abberivation
    #    self.frequency = frequency
     #   self.first_name = []
      #  self.last_name = []


    
