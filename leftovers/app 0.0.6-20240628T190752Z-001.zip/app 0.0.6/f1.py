#from tkinter import *
#from random import *
from driver import *
from serie import *
from team import *
from graphics import *
from datetime import *

print('hello')
series.append(Series('F1',1999,1,1))
manufacturers.append(Manufacturer('Ferrari',[Component('E71',date(2000,1,7),date(2001,1,18),'E',['F1'],71),Component('C71',date(2000,1,18),date(2001,1,18),'C',['F1'],71)],0,1947))
manufacturers.append(Manufacturer('Mercedes',[Component('SA1',date(2000,1,1),date(2003,1,18),'E',['F1'],10)],0,1922))
manufacturers.append(Manufacturer('Pirelli',[Component('PZero',date(1970,1,18),date(2001,1,18),'P',['F1'],20)],1,1947))
teams.append(Team('Williams',1947,0,[],[],[],[]))
teams.append(Team('McLaren',1958,0,[],[],[],[]))

add_event(date(2000,1,10),'ND',[6])
add_event(date(2000,1,11),'NC',[0,0,400000,date(2000,2,1)])
add_event(date(2000,1,11),'NC',[1,1,500000,date(2000,2,3)])
add_event(date(2000,1,11),'NC',[2,0,500000,date(2000,2,2)])
add_event(date(2000,1,11),'NC',[3,1,1000,date(2000,1,21)])
add_event(date(2000,1,11),'NC',[4,0,50000,date(2000,1,22)])
add_event(date(2000,1,11),'NC',[5,1,8000000,date(2000,1,23)])
add_event(date(2000,1,13),'BD',[0])
add_event(date(2000,1,14),'BD',[1])
add_event(date(2000,1,15),'BD',[2])
add_event(date(2000,1,16),'BD',[3])
add_event(date(2000,1,17),'BD',[4])
add_event(date(2000,1,18),'BD',[5])
add_event(date(2000,1,19),'R',[[[[0],0,[[0,0],[0,1],[2,0]],25], [[1],1,[[1,0],[0,1],[2,0]],26]],'Spa',0])
add_event(date(2000,1,19),'R',[[[[4,0],0,[[0,0],[0,1],[2,0]],25], [[5,1],1,[[1,0],[0,1],[2,0]],26], [[2],0,[[0,0],[0,1],[2,0]],28], [[3],1,[[1,0],[0,1],[2,0]],27]],'Monza',0])



#events.append([date(2000,1,10),'ND',6])
#events.append([date(2000,1,11),'NC',0,0,500000,2010])
#events.append([date(2000,1,11),'NC',1,1,500000,2002])
#events.append([date(2000,1,11),'NC',2,0,500000,2050])
#events.append([date(2000,1,11),'NC',3,1,500000,2005])
#events.append([date(2000,1,11),'NC',4,0,500000,2048])
#events.append([date(2000,1,11),'NC',5,1,8000000,2013])
#events.append([date(2000,1,12),'R',[[[0],0,[[0,0],[0,1],[2,0]],25], [[1],1,[[1,0],[0,1],[2,0]],26]],'Spa',0])

#events.append([date(2000,1,13),'R',[[[4,0],0,[[0,0],[0,1],[2,0]],25], [[5,1],1,[[1,0],[0,1],[2,0]],26], [[2],0,[[0,0],[0,1],[2,0]],28], [[3],1,[[1,0],[0,1],[2,0]],27]],'Monza',0])

#events.append([date(2000,2,1),'NY'])
