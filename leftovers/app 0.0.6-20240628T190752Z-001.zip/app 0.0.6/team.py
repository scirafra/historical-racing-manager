teams=[]
manufacturers=[]

class Team:
    def __init__( self , name , since, nationality, driver_contracts ,component_contracts, history, team_property ) :
        self.name = name
        self.since = since
        self.nationality = nationality
        self.driver_contracts = driver_contracts
        self.component_contracts = component_contracts
        self.history = history
        self.team_property = team_property

class Manufacturer:
    def __init__( self , name , components, nationality, since ) :
        self.name = name
        self.since = since
        self.nationality = nationality
        self.components = components

class Component:
    def __init__( self , name, since, until, component_type , rule, ability ) :
        self.name = name
        self.component_type = component_type
        self.rule = rule
        self.ability = ability

class Driver_contract:
    def __init__( self , driver, team , wage, year_of_end ) :
        self.driver = driver
        self.team = team
        self.wage = wage
        self.year_of_end = year_of_end

    
