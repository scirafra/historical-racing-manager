from tkinter import *
#from datef1 import *
from driver import *
from team import *
from serie import *
from datetime import *
xy=[10,80,1770,990]
start_date=date(2000,1,9)
today=start_date
events=[]
past_events=[]


#todai=date(2000,8,1)
#print(5+(today-todai).days)

#def skip7days():
 #   global today
  #  today=today+timedelta(days=7)
   # return str(today.strftime('%A %d %B %Y'))


def white_screen(xy):
        a.create_rectangle(xy[0],xy[1],xy[2],xy[3],fill='white')
        a.update()
        
def a():
        a.create_text(230,350,text='a',font='Arial20')
        a.create_oval(10, 10, 10, 10, fill='red')
        a.update()
        print('print')

def happy_birthday(name):
        white_screen(xy)
        a.create_text(230,350,text=name,font='Arial20')
        a.create_oval(200, 200, 220, 220, fill='red')
        a.update()
        print('Happy Birthday',name)

def add_event(date,event,data):
        
        day=(date-today).days
        if len(events)<(day+1):
                for i in range(day-len(events)+1):
                        events.append([])
        events[day].append([event,data])
        print(events)
        
        

def event_decider():
        day=(today-start_date).days
        if len(events)>day:
                print('tu',len(events[day]),today)
                
                for e in range(len(events[day])):
                        print(len(events))
        #if len(events)>0 and events[0][0]==today:
                        print(events[day][e][0])
                        if events[day][e][0]=='BD':
                                happy_birthday(events[day][e][1][0])
                        elif events[day][e][0]=='NY':
                                update_driver_abilities()
                                print_person()
                        elif events[day][e][0]=='ND':
                                for i in range(events[day][e][1][0]):
                                        generate_driver()
                        elif events[day][e][0]=='R':
                                print('race')
                        #print(events[0][3],series[events[0][4]].name)
                                race(events[day][e][1][0],events[day][e][1][1],events[day][e][1][2])
                        #for i in range(len(events[0][2])):
                                #print(events[0][2][i][0][0],events[0][2][i][1])
                                #print(drivers[events[0][2][i][0][0]].last_name,teams[events[0][2][i][1]].name,"Engine:",manufacturers[events[0][2][i][2][0][0]].components[events[0][2][i][2][0][1]].name,"Car number:",events[0][2][i][2])
                        elif events[day][e][0]=='NC':
                                teams[events[day][e][1][1]].driver_contracts.append(Driver_contract(events[day][e][1][0],events[day][e][1][1],events[day][e][1][2],events[day][e][1][3]))
                                add_event(events[day][e][1][3],'EC',[events[day][e][1][0],events[day][e][1][1]])
                                print(teams[events[day][e][1][1]].driver_contracts[-1].driver,teams[events[day][e][1][1]].driver_contracts[-1].team,teams[events[day][e][1][1]].driver_contracts[-1].wage,teams[events[day][e][1][1]].driver_contracts[-1].year_of_end)
                        elif events[day][e][0]=='EC':
                                print(len(teams[events[day][e][1][1]].driver_contracts),' jazdcov ',teams[events[day][e][1][1]].driver_contracts[-1].driver,teams[events[day][e][1][1]].driver_contracts[-1].team,teams[events[day][e][1][1]].driver_contracts[-1].wage,teams[events[day][e][1][1]].driver_contracts[-1].year_of_end)
                                for i in range (len(teams[events[day][e][1][1]].driver_contracts)):
                                        print()
                                        if teams[events[day][e][1][1]].driver_contracts[i].driver==events[day][e][1][0]:
                                                del teams[events[day][e][1][1]].driver_contracts[i]
                                                break
                                #teams[events[day][e][1][1]].driver_contracts.append(Driver_contract(events[day][e][1][0],events[day][e][1][1],events[day][e][1][2],events[day][e][1][3]))
                                
                #past_events.append (events[0])
                #events.remove (events[0])
        
        else:
              print('tu no more ',today)  
        print('Luck',len(events))     
        
        #event_decider()
    
def skip1day():
    global today
    today=today+timedelta(days=1)
    event_decider()
    print(start_date,today)
    return str(today.strftime('%A %d %B %Y'))

def skip7():
        for i in range(360):
                date_label.config(text=skip1day())

def skip1():
        date_label.config(text=skip1day())        



a=Canvas(height=1015,width=1918,bg='yellow')
a.pack()

def aa():
        a.create_text(230,350,text='a',font='Arial20')
        a.create_oval(100, 100, 210, 210, fill='red')
        a.update()
        print('print')

#a.create_text(230,350,text='a',font='Arial20')
white_screen(xy)
e1=Entry(text='Sebastian Raikkonnenn-Schumacher',width=27)
e1.place(x=1600,y=40)
l1=Label(text='Frantisek Schumacher-Raikkonnenn',width=30)
l1.place(x=50,y=10)
l2=Label(text='1984',width=30)
l2.place(x=50,y=40)
l3=Label(text='Plat jazdca',width=30)
l3.place(x=1600,y=10)
date_label=Label(text=today.strftime('%A %d %B %Y'),width=24)
date_label.place(x=1400,y=40)
b1=Button(text='<',width=3,command=a)
b1.place(x=10,y=10)
b2=Button(text='<',width=3,command=a)
b2.place(x=10,y=40)
b3=Button(text='>',width=3,command=a)
b3.place(x=270,y=10)
b4=Button(text='>',width=3,command=a)
b4.place(x=270,y=40)
b5=Button(text='Rekordy jazdca',width=16,command=a)
b5.place(x=400,y=10)
b6=Button(text='Jazdec',width=16,command=a)
b6.place(x=400,y=40)
b7=Button(text='Rekordy timu',width=16,command=a)
b7.place(x=600,y=10)
b8=Button(text='Tim',width=16,command=a)
b8.place(x=600,y=40)
b9=Button(text='Rekordy konstruktera',width=16,command=a)
b9.place(x=800,y=10)
b10=Button(text='Konstrukter',width=16,command=a)
b10.place(x=800,y=40)
b11=Button(text='Rekordy serie',width=16,command=a)
b11.place(x=1000,y=10)
b12=Button(text='Seria',width=16,command=a)
b12.place(x=1000,y=40)
b13=Button(text='Noviky',width=16,command=a)
b13.place(x=1780,y=170)
b14=Button(text='Jazdci',width=16,command=a)
b14.place(x=1780,y=200)
b15=Button(text='Zamestnanci',width=16,command=a)
b15.place(x=1780,y=230)
b16=Button(text='Financie',width=16,command=a)
b16.place(x=1780,y=260)
b17=Button(text='Auto/Suciastky',width=16,command=a)
b17.place(x=1780,y=290)
b18=Button(text='Vyvoj',width=16,command=a)
b18.place(x=1780,y=320)
b19=Button(text='Serie',width=16,command=a)
b19.place(x=1780,y=350)
b20=Button(text='Sponzory',width=16,command=a)
b20.place(x=1780,y=380)
b21=Button(text='Pretek',width=16,command=a)
b21.place(x=1780,y=410)
b22=Button(text='Info',width=16,command=a)
b22.place(x=1200,y=40)
b23=Button(text='Vykonaj',width=16,command=aa)
b23.place(x=1780,y=40)
b24=Button(text='Dalsi den',width=16,command=skip1)
b24.place(x=1780,y=80)
b25=Button(text='Preskoc 7 dni',width=16,command=skip7)
b25.place(x=1780,y=110)


