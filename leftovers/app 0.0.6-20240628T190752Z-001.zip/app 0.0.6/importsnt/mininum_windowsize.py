#Import the required libraries
from tkinter import *

#Create an instance of tkinter frame
win= Tk()

#Minimize the window
win.minsize(1200, 720)

#Create a text label
Label(win, text= "Window Size is minimized to 150x100",font=('Helvetica bold',20)).pack(pady=20)

win.mainloop()
