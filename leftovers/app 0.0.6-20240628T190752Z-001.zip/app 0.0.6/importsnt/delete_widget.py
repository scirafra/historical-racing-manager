from tkinter import *

root = Tk()

def clear():
    list = root.grid_slaves()
    print(list)
    for l in list:
        l.destroy()
    a.destroy()

Label(root,text='Hello World!').grid(row=0)
a=Button(root,text='Clear',command=clear)
a.place(x=10,y=10)
Label(root,text='Hello World!').grid(row=1)

root.mainloop()
