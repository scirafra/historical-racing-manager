from driver import *
#from manufaturer import *
from random import *
from team import *
#from f1 import *
series=[]
class Series:
    def __init__( self , name , found_year, reputation, seasons) :
        self.name = name
        self.found_year = found_year
        self.reputation = reputation
        self.seasons = seasons
  

class Season:
    def __init__( self , series_name , year, drivers_and_points ,races ) :
        self.series_name = series_name
        self.year = year
        self.drivers_and_points = drivers_and_points
        self.races = races

class Pointsystem:
    def __init__( self , year, system ) :
        self.year = year
        self.system = system

class Race:
    def __init__( self , name , found_year, results) :
        self.name = name
        self.year = year
        self.results = results

        

class Track:
    def __init__( self , name , build_year, reputation, year) :
        self.name = name
        self.build_year = build_year
        self.reputation = reputation
        self.variants = variants
        self.active_variants = []
        for i in variants:
            if i.since <= year and i.until >= year :
                active_variants.append ( i )
        
        global id
        self.id = id
        id += 1

class Track_variant:
    def __init__( self , name , since, until, length) :
        self.name = name
        self.since = since
        self.until = until
        self.length = length
    

        
def race(entry,track,seria):
    print(series[seria].name,track)
    e=list(entry)
    #e.copy(entry)
    result=[]
    for i in range(len(entry)-1):
        #print(len(entry)-i)
        x=randrange(0,len(entry)-i)
        result.append(e[x])
        e.remove(e[x])
    result.append(e[0])
    for i in range (len(result)):
        for j in range(len(result[i][0])):
            print(i+1,drivers[result[i][0][j]].first_name,drivers[result[i][0][j]].last_name,teams[result[i][1]].name,'Car number:',result[i][3])
    #print(result)
    
