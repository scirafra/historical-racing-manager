from random import *
nationalities=[]

class Person_name:
    def __init__( self , name , frequency ) :
        self.name = name
        self.frequency = frequency

class Nationality:
    def __init__( self , name , abberivation ,frequency, first_names, last_names ) :
        self.name = name
        self.abberivation = abberivation
        self.frequency = frequency
        self.first_names = first_names
        self.last_names = last_names

def load_nationality(file):
    with open(str(file)+".txt", 'r') as f:
        national_frequency=0
        for line in f:
            first_names=[]
            last_names=[]
            first_name_frequency=0
            last_name_frequency=0
            line=line.rstrip()
            line=line.split(',')
            if len(line)<2:
                break
            
            for i in range (len(line)):
                line[i]=line[i].split(' ')
            
            for j in range (len(line[1])):
                line[1][j]=line[1][j].split('.')
                first_name_frequency=first_name_frequency+int(line[1][j][1])
                first_names.append(Person_name(line[1][j][0],first_name_frequency))
            
            for j in range (len(line[2])):
                line[2][j]=line[2][j].split('.')
                last_name_frequency=last_name_frequency+int(line[2][j][1])
                last_names.append(Person_name(line[2][j][0],last_name_frequency))
            national_frequency=national_frequency+int(line[0][2])
            nationalities.append(Nationality(line[0][0],line[0][1],national_frequency,first_names,last_names))
            
        else:
            # No more lines to be read from file
            x=0
def sort_nationality(file):
    nationalities=[]
    with open(str(file)+".txt", 'r') as f:
        for line in f:
            line=line.rstrip()
            line=line.split(',')
            if len(line)<2:
                break
            for i in range (1,len(line)):
                line[i]=line[i].split(' ')
                line[i].sort()
            nationalities.append(line)
        else:
            # No more lines to be read from file
            x=0
    print('aaaaa',nationalities,'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
    with open(str(file)+".txt", 'w') as f:
        nation=[]
        for i in range(len(nationalities)):
            nation.append(nationalities[i][0])
            nation[i]+=','
            
            for j in range(len(nationalities[i][1])-1):
                nation[i]+=nationalities[i][1][j]
                nation[i]+=' '
            nation[i]+=nationalities[i][1][-1]
            nation[i]+=','
            
            #nation[i][-1]=','
            for j in range(len(nationalities[i][2])-1):
                nation[i]+=nationalities[i][2][j]
                nation[i]+=' '
            nation[i]+=nationalities[i][2][-1]
            nation[i]+='\n'
            print(nation[i])
            #nation[i][-1]='\n'
            #print('xXxXxXx',nation[i])
        nation.sort()
        f.writelines(nation)

    
load_nationality("nationalities")

def binary_search(arr, low, high, x):
 
    # Check base case
    if high >= low:
 
        mid = (high + low) // 2
 
        # If element is present at the middle itself
        if arr[mid].frequency > x and arr[mid-1].frequency <= x:
            return mid
 
        # If element is smaller than mid, then it can only
        # be present in left subarray
        elif arr[mid].frequency > x:
            return binary_search(arr, low, mid - 1, x)
 
        # Else the element can only be present in right subarray
        else:
            return binary_search(arr, mid + 1, high, x)
 
    else:
        # Element is not present in the array
        return -1

def generate_name():
    x=randrange( nationalities[-1].frequency )
    if x<nationalities[0].frequency:
        nationality=0
    else:
        nationality=binary_search(nationalities, 1, len(nationalities)-1, x)
    x=randrange( nationalities[nationality].first_names[-1].frequency )
    if x<nationalities[nationality].first_names[0].frequency:
        first_name=0
    else:
        first_name=binary_search(nationalities[nationality].first_names, 1, len(nationalities[nationality].first_names)-1, x)
    x=randrange( nationalities[nationality].last_names[-1].frequency )
    if x<nationalities[nationality].last_names[0].frequency:
        last_name=0
    else:
        last_name=binary_search(nationalities[nationality].last_names, 1, len(nationalities[nationality].last_names)-1, x)
    return [nationalities[nationality].first_names[first_name].name, nationalities[nationality].last_names[last_name].name,nationality]
for i in range(24):
    a=generate_name()
    print (a[0],a[1],nationalities[a[2]].name)
