#from Drivers import *
#from Teams import *
series=[]
class Series:
    def __init__( self , name , found_year, reputation, seasons) :
        self.name = name
        self.found_year = found_year
        self.reputation = reputation
        self.seasons = seasons
  

class Season:
    def __init__( self , series_name , year, drivers_and_points ,races ) :
        self.series_name = series_name
        self.year = year
        self.drivers_and_points = drivers_and_points
        self.races = races

class Pointsystem:
    def __init__( self , year, system ) :
        self.year = year
        self.system = system

class Race:
    def __init__( self , name , found_year, results) :
        self.name = name
        self.year = year
        self.results = results

        

class Track:
    def __init__( self , name , build_year, reputation, year) :
        self.name = name
        self.build_year = build_year
        self.reputation = reputation
        self.variants = variants
        self.active_variants = []
        for i in variants:
            if i.since <= year and i.until >= year :
                active_variants.append ( i )
        
        global id
        self.id = id
        id += 1

class Track_variant:
    def __init__( self , name , since, until, length) :
        self.name = name
        self.since = since
        self.until = until
        self.length = length
    


    
