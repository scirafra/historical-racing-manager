from a import *


def kreslib():
    print('b')

