from b import *


def kresli():
    print('a')

