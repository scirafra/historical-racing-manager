from datetime import *
events=[]
start_date=date(2000,1,1)
today=date(2008,2,1)
todai=date(2000,2,1)
print((today-todai).days)
#events.append([date(2000,1,18),'N',happy_birthday('Feri')])
def skip7days():
    global today
    today=today+timedelta(days=7)
    return str(today.strftime('%A %d %B %Y'))
    
def skip1day():
    global today, today_word
    today=today+timedelta(days=1)
    return str(today.strftime('%A %d %B %Y'))
